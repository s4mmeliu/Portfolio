﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lottonumeroitaa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Arvo_Click(object sender, EventArgs e)
        {
            try
            {
                //Luo satunnaisen luvun 1-40 numeron väliltä
                Random random = new Random();
                List<int> randomNumbers = new List<int>();
                while (randomNumbers.Count <= 7) // 7 eri numeroa
                                                
                {
                    int numero = random.Next(1, 40); // 1-40 numeron rangelta
                    if (!randomNumbers.Contains(numero)) {randomNumbers.Add(numero); } // tarkistaa että numeroita ei ole käytetty aiemmin
                    
                }
                randomNumbers.Sort();

                txt_Numerot.Text = string.Join(Environment.NewLine, randomNumbers);
                
            }
            catch (Exception) { MessageBox.Show("Jokin meni pieleen "); }
        }
    
    }
}
