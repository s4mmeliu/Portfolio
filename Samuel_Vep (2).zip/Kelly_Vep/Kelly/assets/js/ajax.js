// ajax_send_form.js

document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("your-form-id");

    form.addEventListener("submit", function(event) {
        event.preventDefault();

        const formData = new FormData(form);

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "contact.php", true);
        xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");

        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Onnistunut vastaus
                    console.log(xhr.responseText);
                    // Voit lisätä tähän tarvittavat toimenpiteet, esim. ilmoitus käyttäjälle
                } else {
                    // Virhe tapahtui
                    console.error("Virhe: " + xhr.status);
                }
            }
        };

        xhr.send(formData);
    });
});
