﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bonussss
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            string obfuskoituTeksti = "T4m4 v135t1 31 s44 j0utu4 ulk0pu0l1st3n kä51in. Funkt10 on 3l1ntärk34. Muu77uj4 s1s4lt44 \r\nk4ytt4j4t13d0t. 51lmukk4 on funk710n sydän. L0ppu. "; // näiden lainausmerkkien väliin pitäisi varmaan laittaa purettava koodi 
            StringBuilder deobfuskoituTeksti = new StringBuilder(); // tähän tallennetaan selvitetty koodi
            string[] avainSanat = { "funktio", "muuttuja", "silmukka" }; // Tähän ilmeisesti pitäisi saada viestissä olevat avainsanat


            int avainsana1 = 0, avainsana2 = 0, avainsana3 = 0; // Näihän pitäisi laskea avain sanojen lukumäärä 
                                                                //Tämä silmukka ilmeisesti käy tekstin läpi merkki merkiltä... 
            foreach (char merkki in obfuskoituTeksti)
            {
                if (merkki == '0')
                { //tähän pitäisi laittaa jotain... 
                    deobfuskoituTeksti.Append('o'); // samoin tästä puuttuu jotain... 
                }

                else if (merkki == '1')
                { //tähän pitäisi laittaa jotain... 
                    deobfuskoituTeksti.Append('i'); // samoin tästä puuttuu jotain... 
                }

                else if (merkki == '3')
                { //tähän pitäisi laittaa jotain... 
                    deobfuskoituTeksti.Append('e'); // samoin tästä puuttuu jotain... 
                }

                else if (merkki == '4')
                { //tähän pitäisi laittaa jotain... 
                    deobfuskoituTeksti.Append('a'); // samoin tästä puuttuu jotain... 
                }

                else if (merkki == '5')
                { //tähän pitäisi laittaa jotain... 
                    deobfuskoituTeksti.Append('s'); // samoin tästä puuttuu jotain... 
                }

                else if (merkki == '7')
                { //tähän pitäisi laittaa jotain... 
                    deobfuskoituTeksti.Append('t'); // samoin tästä puuttuu jotain... 
                }
                else
                {
                    deobfuskoituTeksti.Append(merkki);
                }

                string[] sanat = deobfuskoituTeksti.ToString().Split(' ', '\r', '\n', '.', ',');
                textBox1.Text = "Obfuskoitu koodi.:" + Environment.NewLine;
                textBox1.Text += obfuskoituTeksti + Environment.NewLine + Environment.NewLine;
                textBox1.Text += deobfuskoituTeksti + Environment.NewLine + Environment.NewLine;

                foreach (var avainSana in avainSanat)
                {
                    int lukuMaara = 0;
                    foreach (var sana in sanat)
                    {
                        if (sana.ToLower().Trim() == avainSana || (avainSana == "funktio" && sana.ToLower().Trim() == "funktion"))
                        {
                            lukuMaara++;
                            if (avainSana == "funktio" || avainSana == "funktion")
                            {
                                avainsana1++;
                            }
                            else if (avainSana == "muuttuja")
                            {
                                avainsana2++;
                            }
                            else if (avainSana == "silmukka")
                            {
                                avainsana3++;
                            }
                            /* textBox1.Text += $"Avainsana '{avainSana}' esiintyy {lukuMaara} kertaa," + Environment.NewLine;


                         }
                         /*textBox1.Text += $"Avainsana 'funktio' esiintyy yhteensä {avainsana1} kertaa." + Environment.NewLine;
                         textBox1.Text += $"Avainsana 'muuttuja' esiintyy yhteensä {avainsana2} kertaa." + Environment.NewLine;
                         textBox1.Text += $"Avainsana 'silmukka' esiintyy yhteensä {avainsana3} kertaa." + Environment.NewLine;*/

                        }
                    }
                    textBox1.Text += $"Avainsana '{avainSana}' esiintyy {lukuMaara} kertaa," + Environment.NewLine;
                }
               /* textBox1.Text += $"Avainsana 'funktio' esiintyy yhteensä {avainsana1} kertaa." + Environment.NewLine;
                         textBox1.Text += $"Avainsana 'muuttuja' esiintyy yhteensä {avainsana2} kertaa." + Environment.NewLine;
                         textBox1.Text += $"Avainsana 'silmukka' esiintyy yhteensä {avainsana3} kertaa." + Environment.NewLine; */
            }
        }
    }
}   
